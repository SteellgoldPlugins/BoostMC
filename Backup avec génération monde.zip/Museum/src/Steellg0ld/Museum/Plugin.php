<?php

namespace Steellg0ld\Museum;

use muqsit\invmenu\InvMenuHandler;
use pocketmine\entity\Entity;
use pocketmine\level\biome\Biome;
use pocketmine\level\generator\Generator;
use pocketmine\level\generator\GeneratorManager;
use pocketmine\level\generator\hell\Nether;
use pocketmine\level\Level;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\Config;
use Steellg0ld\Museum\base\Database;
use Steellg0ld\Museum\base\Economy;
use Steellg0ld\Museum\base\Player;
use Steellg0ld\Museum\commands\defaults\Money;
use Steellg0ld\Museum\commands\defaults\Rank;
use Steellg0ld\Museum\commands\defaults\Settings;
use Steellg0ld\Museum\commands\defaults\Shop;
use Steellg0ld\Museum\entity\Wither;
use Steellg0ld\Museum\listeners\player\PlayerListener;
use Steellg0ld\Museum\listeners\server\LevelListener;
use Steellg0ld\Museum\tasks\async\LoadDatabase;
use Steellg0ld\Museum\utils\Utils;

class Plugin extends PluginBase
{
    public static $instance;
    CONST FILE_DB = "data.db";

    public static ?Level $netherLevel;

    public function onEnable()
    {
        self::$instance = $this;

        @mkdir($this->getDataFolder() . "langs/");
        $this->saveResource("langs/fr_FR.yml");

        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }

        $this->getDatabase()->initialize();
        $this->loadCommands();
        $this->loadListeners();
        $this->loadEntitys();
        $this->loadGenerators();
        $this->getServer()->getAsyncPool()->submitTask(new LoadDatabase());
        \Steellg0ld\Museum\base\Level::loadAndGenerateLevels();
    }

    public function onDisable()
    {
        Utils::saveAll();
        foreach (Server::getInstance()->getOnlinePlayers() as $player){
            if($player instanceof Player) $this->getDatabase()->player_update($player->getName(),base64_encode(base64_encode(base64_encode($player->getAddress()))),$player->faction,$player->faction_role,$player->rank,$player->money,$player->lang,base64_encode(serialize($player->settings)),$player->discordId);
        }
    }

    public static function getInstance(): self
    {
        return self::$instance;
    }

    public function loadCommands(){
        $this->getServer()->getCommandMap()->registerAll("museum",[
            new Settings("settings","Configure your game","",["configure","setting"]),
            new Settings("settings","Configure your game","",["configure","setting"]),
            new Rank("setrank","Set rank to yourself",""),
            new Shop("shop","Buy a item simply",""),
            new Money("money","Edit the money",""),
            new \Steellg0ld\Museum\commands\defaults\Nether("nether","Change dimension","")
        ]);
    }

    private function loadListeners(){
        $this->getServer()->getPluginManager()->registerEvents(new PlayerListener(), $this);
    }

    private function loadEntitys(){
        Entity::registerEntity(Wither::class, true, ["Wither", "minecraft:wither"]);
    }

    public function getDatabase(): Database{
        return new Database();
    }

    public function getMessages(String $file): Config
    {
        return new Config($this->getDataFolder() . "langs/".$file.".yml", Config::YAML);
    }

    public function getConfigFile(String $file): Config
    {
        return new Config($this->getDataFolder() . $file.".yml", Config::YAML);
    }

    public function getEconomyAPI(): Economy{
        return new Economy();
    }

    private function loadGenerators(){
        GeneratorManager::addGenerator(Nether::class, "custom_nether");
    }
}