<?php

namespace Steellg0ld\Museum\base;

use pocketmine\entity\Entity;
use pocketmine\level\generator\GeneratorManager;
use pocketmine\Server;
use Steellg0ld\Museum\blocks\Portal;
use Steellg0ld\Museum\Plugin;

class Level {
    public static function loadAndGenerateLevels(){
        if(!Server::getInstance()->loadLevel("custom_nether")){
            Server::getInstance()->generateLevel("custom_nether", time(), GeneratorManager::getGenerator("custom_nether"));
        }

        Plugin::$netherLevel = Server::getInstance()->getLevelByName("custom_nether");
    }

    public static function isInsideOfPortal(Entity $entity): bool{
        foreach($entity->getBlocksAround() as $block){
            if($block instanceof Portal){
                return true;
            }
        }

        return false;
    }
}