<?php

namespace Steellg0ld\Museum\base;

class Homes{

}