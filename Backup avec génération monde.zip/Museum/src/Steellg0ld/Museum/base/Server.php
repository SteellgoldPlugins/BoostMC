<?php

namespace Steellg0ld\Museum\base;

use pocketmine\Server as PMServer;

class Server extends PMServer {
    public static bool $loaded = false;
}
